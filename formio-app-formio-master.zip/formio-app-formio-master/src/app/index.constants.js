/* global moment:false */
(function() {
  'use strict';
  angular
    .module('formioApp')
    .constant('moment', moment);
})();
